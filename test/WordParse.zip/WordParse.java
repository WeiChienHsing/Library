package com.hsing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.analysis.core.StopAnalyzer;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;

import com.atilika.kuromoji.ipadic.Token;
import com.atilika.kuromoji.ipadic.Tokenizer;

public class WordParse {
	public static void main(String[] args) throws IOException {
		
		final String folderPath = "C:\\Users\\Administrator\\Desktop\\test\\";
		japaneseWordParser(folderPath);
		
	}

	public static void englishWordParser(String text, Analyzer analyzer) throws IOException {
		
	}

	public static void japaneseWordParser(final String folderPath) throws IOException {
		// TODO Auto-generated method stub
		Tokenizer tokenizer = new Tokenizer();
		

		Stream<Path> paths = Files.walk(Paths.get(folderPath));

		// = new HashSet<Token>();

		paths.forEach(x -> {

			if (!Files.isDirectory(x)) {
				System.out.println(x);
				Set<Token> tokenSet = new HashSet<Token>();
				try {
					tokenSet.addAll(
							tokenizer.tokenize(new String(Files.readAllBytes(Paths.get(x.toString())), "UTF-8")));

					String output = "";
					Integer counter = 0;
					for (Token token : tokenSet) {
						output += token.getBaseForm() + "\t" + "placeholder\r\n";
						counter++;
						System.out.println(token.getBaseForm());
						System.out.println(token.getReading());
						// System.out.println(counter);
					}

					output += "total words : " + counter + "/r/n";

					Files.write(Paths.get("C:\\\\Users\\\\Administrator\\\\Desktop\\\\output.txt"),
							Collections.singleton(output), StandardCharsets.UTF_8, StandardOpenOption.APPEND);

				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		});
	}
}
