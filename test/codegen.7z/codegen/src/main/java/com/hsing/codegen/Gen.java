package com.hsing.codegen;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

import com.hsing.codegen.utils.DbUtils;

/**
 * Hello world!
 *
 */
public class Gen {
	public static void main(String[] args) throws Exception {

		String vmFilePath = "./src/main/resources/template/Mapper.vm";
		String tblSchema = "ams";
		
		List<String> tblNames = DbUtils.getTblNamesByTblSchema(tblSchema);
		for(String tblName : tblNames) {
			List<String> columnsInfo = DbUtils.getColumnsInfoByTblName(tblName);
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("columns", columnsInfo);
			StringWriter writer = new StringWriter();
			Template template = Velocity.getTemplate(vmFilePath);
			template.merge(velocityContext, writer);
			System.out.println(writer.toString());

		}
		

	}

}

