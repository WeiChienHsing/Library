package com.hsing.codegen.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DbUtils {
	public static List<String> getColumnsInfoByTblName(String tblName) throws Exception {
		List resultList = new ArrayList();
		final String getTableNamesSQL = " select column_name, data_type from information_schema.columns where table_name = ?";
		Connection conn = getMySqlConnection();
		PreparedStatement ps = conn.prepareStatement(getTableNamesSQL);
		ps.setString(1, tblName);
		ResultSet rs = ps.executeQuery();
		
		while(rs.next()) {
			resultList.add(rs.getString(1));
		}
		ps.close();
		conn.close();
		return resultList;
	}
	
	public static List<String> getTblNamesByTblSchema(String tblSchema) throws Exception {
		List resultList = new ArrayList();
		final String getTableNamesSQL = "select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA = ?";
		Connection conn = getMySqlConnection();
		PreparedStatement ps = conn.prepareStatement(getTableNamesSQL);
		ps.setString(1, tblSchema);
		ResultSet rs = ps.executeQuery();	
		while(rs.next()) {
			resultList.add(rs.getString(1));
		}
		ps.close();
		conn.close();
		return resultList;
	}
	
	
	
	private static Connection getMySqlConnection() throws Exception {
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl("jdbc:mysql://localhost:3306/word?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC");
		config.setUsername("root");
		config.setPassword("123456");
		config.addDataSourceProperty("cachePrepStmts", "true");
		config.addDataSourceProperty("prepStmtCacheSize", "250");
		config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
		HikariDataSource ds = new HikariDataSource(config);
		return ds.getConnection();
	}
	
	

}
